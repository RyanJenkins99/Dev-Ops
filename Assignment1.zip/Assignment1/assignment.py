#!/usr/bin/env python3
import boto3
import webbrowser
import subprocess
from botocore.exceptions import ClientError
ec2 = boto3.resource('ec2')
# Retrieve the website configuration
s3 = boto3.resource("s3")
client = boto3.client('sns')
sns = boto3.client('sns')



# creates the instance, which includes the tag specifications, security groups and the key
try:    
    instance = ec2.create_instances(
   
        ImageId= 'ami-0d1bf5b68307103c2',
        MinCount=1,
        MaxCount=1,
        InstanceType='t2.nano',
        SecurityGroupIds=[
            'sg-009eac418e59e0660'    
        ],
        KeyName='Rjenkins_key',
        TagSpecifications = [
            {
                "ResourceType":"instance",
                "Tags": [
                    {
                        "Key": "Rjenkins_key",
                        "Value": "Assignment"
                    }
                ]
            }
        ],
        
        # error which doesn't display on the website
        UserData =
            '''
            #!/bin/bash
            apt-get update                                 
            yum install httpd -y                           
            systemct1 enable httpd
            systemct1 start httpd 
            echo '<html>' > index.html
            echo 'Private IP address: ' >> index.html
            echo 'Public IP address:  ' >>index.html
            curl -s http://169.254.169.254/latest/meta-data/public-ipv4 >> index.html
            cp index.html /var/www/html/index.html
            ''',
        )

        
    
    print("Creating Instance") 
except:
    print("Instance creation error")

# pretty sure this doesn't work
def get_public_ip(instance_id):
    ec2_client = boto3.client("ec2", region_name="eu-west-1")
    reservations = ec2_client.describe_instances(InstanceIds=[instance_id]).get("Reservations")

    for reservation in reservations:
        for instance in reservation['Instances']:
            print(instance.get("public_ip_address"))


      # HTTP and SSH

instance[0].wait_until_running()
instance[0].reload()

print("Instance is running")

# creates a bucket
# THe region must be stated in order to create the bucket
try:
    response = s3.create_bucket(Bucket='mybucketjenkins', CreateBucketConfiguration={'LocationConstraint': 'eu-west-1'})
    print (response)
except Exception as error:
    print (error)


# Define the website configuration
website_configuration = {
    'IndexDocument': {'Suffix': 'index.html'},
    'ErrorDocument': {'Key': 'error.html'}
}
print("Website has been configured")



# Set the website configuration, attaches bucket to the webssite 
try:
    s3 = boto3.client('s3')
    s3.put_bucket_website(Bucket='mybucketjenkins',
                        WebsiteConfiguration=website_configuration)
except:
    print("Bucket is not created")


# Upload the file to the s3 bucket
try:
    s3.upload_file(
        'index.html', 'mybucketjenkins', 'index.html',
        ExtraArgs={'ContentType': 'text/html','ACL': 'public-read'}

        )
except:
     print("File has not been uploaded to the s3 bucket")
    

    #In Python, webbrowser module provides a high-level interface which allows displaying Web-based documents to users
    # This also uploads the image to the s3 bucket

webbrowser.open_new_tab('http://mybucketjenkins.s3-website-eu-west-1.amazonaws.com')
webbrowser.open_new_tab('http://' + instance[0].public_ip_address)
print("Image is now uploaded")


# The ssh command provides a secure encrypted connection between two hosts over an insecure network
# The SCP command or secure copy allows secure transferring of files in between the local host and the remote host or between two remote hosts
# The monitor.sh displays the system setting while also showing the instance ID, memory utilisation and the number of processes running
try:
    scp_command = "scp -o StrictHostKeyChecking=no -i Rjenkins_key.pem  monitor.sh ec2-user@"+instance[0].public_ip_address+":."
    ssh_command1 = "ssh -o StrictHostKeyChecking=no -i Rjenkins_key.pem ec2-user@"+instance[0].public_ip_address+" 'chmod 700 monitor.sh'"
    ssh_command2 = "ssh -o StrictHostKeyChecking=no -i Rjenkins_key.pem ec2-user@"+instance[0].public_ip_address+" ' ./monitor.sh'"
    subprocess.run(scp_command,shell=True)
    subprocess.run(ssh_command1,shell=True)
    subprocess.run(ssh_command2,shell=True)
except:
     print("Failed")


# Sending the text

try:
    smsattrs = {
        'AWS.SNS.SMS.SenderID': { 'DataType': 'String', 'StringValue': 'DevOps' },
        'AWS.SNS.SMS.SMSType': { 'DataType': 'String', 'StringValue': 'Transactional'}
    }
    sns.publish(
        PhoneNumber = '+353851599865',
        Message = 'Congratulaions the instance was created and S3 Bucket has been Configured!',
        MessageAttributes = smsattrs
)
except:
     print("Failed to send sns text")






# references:
# Website CONFIG:
# https://boto3.amazonaws.com/v1/documentation/api/latest/guide/s3-example-static-web-host.html

# https://www.learnaws.org/2020/12/16/aws-ec2-boto3-ultimate-guide/#code
# function to get public ip address and instance ID

# reference: potential ideas
# https://hands-on.cloud/working-with-ec2-instances-using-boto3-in-python/

# SNS TEXT
# https://stackoverflow.com/questions/41045868/error-sending-a-sms-with-amazon-sns-and-python-and-boto3

















































