#!/usr/bin/env python3
import sys
import boto3
s3 = boto3.resource('s3')

try:
    bucket = s3.Bucket('Ryan-Jenkins-assignment-bucket')
    for key in bucket.objects.all():
        try:
            key.delete()
            print ('Bucket content deletion successful.')
        except Exception as error:
            print('Bucket content deletion unsuccessful. Error: ')
            print (error)
    try:
        bucket.delete()
        print ('Bucket deletion successful.')
        
    except Exception as error:
        print('Bucket deos not exist')
    ec2 = boto3.resource('ec2')
    for instance in ec2.instances.all():
        try:
            instance.terminate()
        
        except Exception as error:
            print(error)
except Exception as error:
    print('Nothing to delete.')
